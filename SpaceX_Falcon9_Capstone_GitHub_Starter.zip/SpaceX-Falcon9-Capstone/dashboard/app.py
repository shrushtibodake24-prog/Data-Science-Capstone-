"""SpaceX launch outcome dashboard. Set SPACEX_DASH_DATA to a compatible CSV."""
import os
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

DATA_URL = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DS0321EN-SkillsNetwork/datasets/spacex_launch_dash.csv"
DATA_PATH = os.getenv("SPACEX_DASH_DATA", "")
try:
    df = pd.read_csv(DATA_PATH) if DATA_PATH and os.path.exists(DATA_PATH) else pd.read_csv(DATA_URL)
except Exception as exc:
    raise RuntimeError("Download spacex_launch_dash.csv or set SPACEX_DASH_DATA to its path.") from exc

# Column names follow the IBM dashboard dataset. Adjust mapping if your file uses other names.
site_col = "Launch Site"
class_col = "class"
payload_col = "Payload Mass (kg)"
booster_col = "Booster Version Category"
for col in [site_col, class_col, payload_col]:
    if col not in df.columns: raise ValueError(f"Required dashboard column missing: {col}. Available: {df.columns.tolist()}")
if booster_col not in df.columns: df[booster_col] = "Unknown"

app = Dash(__name__)
app.title = "SpaceX Launch Outcome Dashboard"
app.layout = html.Div([
    html.H1("SpaceX Falcon 9 Launch Outcome Dashboard"),
    html.Label("Launch Site"),
    dcc.Dropdown(id="site", options=[{"label":"All Sites","value":"ALL"}] + [{"label":s,"value":s} for s in sorted(df[site_col].dropna().unique())], value="ALL"),
    html.Label("Payload Mass Range (kg)"),
    dcc.RangeSlider(id="payload", min=float(df[payload_col].min()), max=float(df[payload_col].max()), step=100, value=[float(df[payload_col].min()), float(df[payload_col].max())], tooltip={"placement":"bottom","always_visible":False}),
    html.Div(id="charts", style={"display":"grid","gridTemplateColumns":"1fr 1fr","gap":"18px"})
], style={"fontFamily":"Arial","margin":"24px"})

@app.callback(Output("charts","children"), Input("site","value"), Input("payload","value"))
def update(site, payload_range):
    d = df[(df[payload_col] >= payload_range[0]) & (df[payload_col] <= payload_range[1])]
    if site != "ALL": d = d[d[site_col] == site]
    counts = d[class_col].value_counts().rename_axis("Outcome").reset_index(name="Count")
    pie = px.pie(counts, names="Outcome", values="Count", title="Launch Outcomes")
    scatter = px.scatter(d, x=payload_col, y=class_col, color=booster_col, title="Payload Mass vs Landing Outcome", hover_data=[site_col])
    return [dcc.Graph(figure=pie), dcc.Graph(figure=scatter)]

if __name__ == "__main__":
    app.run(debug=True)
