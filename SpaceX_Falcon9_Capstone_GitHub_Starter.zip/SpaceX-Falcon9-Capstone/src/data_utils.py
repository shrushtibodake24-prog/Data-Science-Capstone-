"""Reusable utilities for the SpaceX Falcon 9 capstone."""
from pathlib import Path
import requests
import pandas as pd

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
RAW_DIR = DATA_DIR / "raw"
RAW_DIR.mkdir(parents=True, exist_ok=True)
COURSE_DATASET = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DS0321EN-SkillsNetwork/datasets/dataset_part_2.csv"
FEATURE_DATASET = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DS0321EN-SkillsNetwork/datasets/dataset_part_3.csv"

def download_csv(url: str, destination: Path) -> pd.DataFrame:
    destination.parent.mkdir(parents=True, exist_ok=True)
    response = requests.get(url, timeout=45)
    response.raise_for_status()
    destination.write_bytes(response.content)
    return pd.read_csv(destination)

def load_course_dataset(part: int = 2) -> pd.DataFrame:
    if part == 2:
        url, file = COURSE_DATASET, RAW_DIR / "dataset_part_2.csv"
    elif part == 3:
        url, file = FEATURE_DATASET, RAW_DIR / "dataset_part_3.csv"
    else:
        raise ValueError("part must be 2 or 3")
    if file.exists():
        return pd.read_csv(file)
    return download_csv(url, file)
